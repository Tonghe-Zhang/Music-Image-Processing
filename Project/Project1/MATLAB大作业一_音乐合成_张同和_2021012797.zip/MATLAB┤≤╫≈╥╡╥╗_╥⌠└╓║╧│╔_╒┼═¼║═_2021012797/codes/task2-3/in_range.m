%in_range.m
function whether=in_range(x)

whether=0;
if(x>0)
    if(x<2000)
        whether=1;
    end
end

end