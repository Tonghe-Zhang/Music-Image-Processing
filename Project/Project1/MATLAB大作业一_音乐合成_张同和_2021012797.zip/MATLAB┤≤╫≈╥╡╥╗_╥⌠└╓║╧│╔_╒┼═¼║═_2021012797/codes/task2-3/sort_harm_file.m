%sort_harm_file.m 
% write data to the harmony file.
function sort_harm_file(harm_file)
file_ID=fopen(harm_file,'a+');
for i=1:3
    fprintf(harm_ID,"%s\t",H_1(i,:));
    fprintf(harm_ID,"\n");
end
fprintf(harm_ID,"\n");
fclose(file_ID);
end